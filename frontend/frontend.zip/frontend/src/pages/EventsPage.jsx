import React from 'react';

function EventsPage() {
  return (
    <div className="events-page">
      <h2>Events</h2>
      <p>List of upcoming events will be displayed here.</p>
      {/* You can add more content and functionality here */}
    </div>
  );
}

export default EventsPage;
