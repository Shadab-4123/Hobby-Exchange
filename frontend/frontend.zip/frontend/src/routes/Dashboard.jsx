import React from 'react';

function Dashboard() {
  return (
    <div>
      <h2>User Dashboard</h2>
      {/* Add dashboard content here */}
    </div>
  );
}

export default Dashboard;
